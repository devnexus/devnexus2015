import java.util.List;
import java.util.Arrays;

public class Tickers {
  public static final List<String> symbols = Arrays.asList(
    "AMD", "HPQ", "IBM", "TXN", "VMW", "XRX", "AAPL", "ADBE",
    "AMZN", "CRAY", "CSCO", "DELL", "GOOG", "INTC", "INTU",
    "MSFT", "ORCL", "TIBX", "VRSN", "YHOO");
}
