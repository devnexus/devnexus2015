Currently an Phonegap app so this code need to be ran through 
cordova prepare with a platform add firefoxos